﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;



public class PlayerHealthBar : MonoBehaviour {

	public Image playerHealthBar;

	public float playerMaxHealth = 100f;

	public float playerHealth;

	public GameObject Canvas;



	// Use this for initialization
	void Start () {
		playerHealthBar = GetComponent<Image> ();
		playerHealth = playerMaxHealth;

	}

	// Update is called once per frame
	void Update () {

		playerHealthBar.fillAmount = playerHealth / playerMaxHealth;
	}

	public void TakeDamage(float Damage)
	{
		
		if (playerHealth > 0) 
		{
			playerHealth -= Damage;
			if (playerHealth <= 0) {
				Destroy (this.transform.parent.parent.parent.gameObject);
				Canvas.SetActive (true);
				//Time.timeScale = 0;


			} else
				Time.timeScale = 1;
		}

	}

}
