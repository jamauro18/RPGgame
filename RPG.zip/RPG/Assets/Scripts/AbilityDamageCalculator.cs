﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AbilityDamageCalculator : MonoBehaviour {

	public GameObject Target;
	public float FireBallDamage = 10f;
	public float FireBallCost = 10f;
	public float SmiteDamge = 5f;

	void OnTriggerEnter(Collider other) 
	{



		if (this.name == "Fireball Projectile(Clone)") 
		{
			Destroy (this.gameObject);
			if(other.gameObject.layer == LayerMask.NameToLayer("Enemy"))
			{
				GameObject Target = other.gameObject;

				Target.GetComponentInChildren<HealthBar> ().TakeDamage (FireBallDamage);


			}
		}
		if (this.name == "Smite Projectile(Clone)") 
		{
			//Destroy (this.gameObject);
			if(other.gameObject.layer == LayerMask.NameToLayer("Enemy"))
			{
				GameObject Target = other.gameObject;
				Target.GetComponentInChildren<HealthBar> ().TakeDamage (SmiteDamge);

			}
		}
	}
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
