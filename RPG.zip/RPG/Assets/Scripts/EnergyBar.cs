﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EnergyBar : MonoBehaviour {



	//public Image playerHealthBar;
	public Image energyBar;
	//public float playerMaxHealth = 100f;
	public float MaxEnergy = 100f;
	//public static float playerHealth;
	public float Energy =100;
	public float Cost;
	public float EnergyRegen=1f;




	// Use this for initialization
	void Start () {

		energyBar =  GetComponent<Image> ();

		Energy = MaxEnergy;
	}

	// Update is called once per frame
	void Update () {
		energyBar.fillAmount = Energy / MaxEnergy;
		//energyBar.transform.rotation = Camera.main.transform.rotation;
		if(Energy>100)
		{
			Energy = 100;
		}else
			Energy += EnergyRegen*Time.deltaTime;
		this.GetComponentInParent<Abilities> ().Spellcast (Energy);

	}

	public void UseEnergy(float Used)
	{
		Debug.Log (Used);

		
		if (Energy >= Used) 
		{
			Energy -= Used;
			if (Energy <= 0) 
			{
				Energy = 0;
			}
		}

	}
}
