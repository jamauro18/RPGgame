﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Character : MonoBehaviour {

	float playerEXP=0;
	float ExpForLevel;
	public int Level=1;
	public Image ExpBar;




	// Use this for initialization
	void Start () {
		
	}

	void Update () {
		ExpForLevel = 1000 * Mathf.Pow (Level, 2);
		Debug.Log (ExpForLevel);
		ExpBar.fillAmount = playerEXP / ExpForLevel;
		if(playerEXP==ExpForLevel)
		{
			playerEXP = 0;
			Level += 1;
		}
		//targetHealthBar.transform.rotation = Camera.main.transform.rotation;

	}


	public void Experience(float Exp)
	{
		
		playerEXP += Exp;
		Debug.Log (playerEXP);

	}


}
