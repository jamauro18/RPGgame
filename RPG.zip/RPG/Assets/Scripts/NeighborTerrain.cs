﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NeighborTerrain : MonoBehaviour {

	public Terrain StartTerrain;
	public Terrain NorthT;
	public Terrain EastT;
	public Terrain NorthEastT;

	// Use this for initialization
	void Start () {
		StartTerrain.SetNeighbors (null, NorthT, EastT, null);
		NorthT.SetNeighbors (null, null, NorthEastT, StartTerrain);
		NorthEastT.SetNeighbors (NorthT,null,null,EastT);
		EastT.SetNeighbors (StartTerrain,NorthEastT, null, null);
		
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
