﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Attributes : MonoBehaviour {

	public float strengthPoints= 0;
	public float agilityPoints= 0;
	public float intellectPoints= 0;
	public float luckPoints= 0;
	public float attributePoints;
	public float maxAttributePoints;
	public int level = 1;


	public string attField;
	public string strField;
	public string agiField;
	public string intField;
	public string lukField;
	public Text strPoints;
	public Text agiPoints;
	public Text intPoints;
	public Text lukPoints;
	public Text attPoints;

	//public Button StrengthButtonPos;
	//public Button StrengthButtonNeg;


	void Start ()
	{
		attributePoints = Mathf.Round ((level + 9));
		maxAttributePoints = Mathf.Round ((level + 9));
	}

	void Update()
	{
		attField = attributePoints + "/" + maxAttributePoints+" Attribute Points";
		strField = strengthPoints + "";
		agiField = agilityPoints + "";
		intField = intellectPoints + "";
		lukField = luckPoints + "";
	}
	public void OnGUI ()
	{

		attPoints.text = attField;
		strPoints.text = strField;
		agiPoints.text = agiField;
		intPoints.text = intField;
		lukPoints.text = lukField;

	}

	public void StrPosClicked()
	{
		if(attributePoints>0)
		{
			strengthPoints += 1;
			attributePoints -= 1;
		}

	}

	public void StrNegClicked()
	{
		if(strengthPoints>0)
		{
			strengthPoints -= 1;
			attributePoints += 1;
		}

	}

	public void AgiPosClicked()
	{
		if(attributePoints>0)
		{
			agilityPoints += 1;
			attributePoints -= 1;
		}

	}

	public void AgiNegClicked()
	{
		if(agilityPoints>0)
		{
			agilityPoints -= 1;
			attributePoints += 1;
		}

	}

	public void IntPosClicked()
	{
		if(attributePoints>0)
		{
			intellectPoints += 1;
			attributePoints -= 1;
		}

	}

	public void IntNegClicked()
	{
		if(intellectPoints>0)
		{
			intellectPoints -= 1;
			attributePoints += 1;
		}

	}

	public void LukPosClicked()
	{
		if(attributePoints>0)
		{
			luckPoints += 1;
			attributePoints -= 1;
		}

	}

	public void LukNegClicked()
	{
		if(luckPoints>0)
		{
			luckPoints -= 1;
			attributePoints += 1;
		}

	}

}
