﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Abilities : MonoBehaviour {
	GameObject Manager;
	GameObject Player;
	TalentPoints talentPoints;
	public Rigidbody FireballProjectile;
	public Rigidbody SmiteProjectile;
	public Rigidbody WhirlwindProjectile;
	float smooth = 5.0f;
	float tiltAngle = 60.0f;

	public int fireball=0;
	public float FireBallCost = 10f;
	public int smite=0;
	public int whirlwind=0;
	public int shield_slam=0;





	// Use this for initialization
	void Start () 
	{

	}
	
	// Update is called once per frame
	void Update () {

		CheckTalents ();		
		//Spellcast ();
	}

	void Energy()
	{
		
	}




	public void Spellcast(float Energy)
	{
		
		GameObject Player = GameObject.Find("Player");
		if(fireball==1 && Input.GetKeyDown("1")&& Energy>FireBallCost)
		{	
			Rigidbody Fireball;
			Fireball = Instantiate(FireballProjectile, transform.position, transform.rotation) as Rigidbody;
			Fireball.velocity = transform.TransformDirection(Vector3.forward * 20);
			Destroy (Fireball.gameObject, 2.0f);
			this.GetComponentInChildren<EnergyBar> ().UseEnergy (FireBallCost);


		}
		if(smite==1 && Input.GetKeyDown("2"))
		{
			Rigidbody Smite;
			Smite = Instantiate(SmiteProjectile, transform.position, transform.rotation) as Rigidbody;
			Smite.velocity = transform.TransformDirection(Vector3.forward * 20);
			Destroy (Smite.gameObject, 1.5f);
			Debug.Log ("I'ma gonna smite yo ass");
		}
		if(whirlwind==1 && Input.GetKeyDown("3"))
		{
			Rigidbody Whirlwind;
			float tiltAroundZ = Input.GetAxis("Horizontal") * tiltAngle;
			float tiltAroundX = Input.GetAxis("Vertical") * tiltAngle;
			Quaternion target = Quaternion.Euler (tiltAroundX, 0, tiltAroundZ);
			Whirlwind = Instantiate(WhirlwindProjectile, transform.position, transform.rotation) as Rigidbody;
			Whirlwind.transform.rotation= Quaternion.Slerp(transform.rotation, target,  Time.deltaTime * smooth);
			Whirlwind.transform.RotateAround(Vector3.zero,Vector3.up,20*Time.deltaTime);
			Destroy (Whirlwind.gameObject, 2.0f);
			Debug.Log ("SPIN SPIN SPIN SPIN");
		}
		if(shield_slam==1 && Input.GetKeyDown("4"))
		{
			Debug.Log ("Knock knock... who's there? Shield. Shield who? I'ma hit you in the head with a shield!");
		}
	}










	void CheckTalents()
	{
		GameObject Manager = GameObject.Find("Manager");
		TalentPoints talentPoints = Manager.GetComponent<TalentPoints>();
		if (talentPoints.MageButton1color == 1) {	
			Debug.Log ("You can use " + talentPoints.MageButton1.name);
			fireball = 1;
		} else
			fireball = 0;
		if (talentPoints.MageButton2color==1)
		{	
			Debug.Log("You can use " + talentPoints.MageButton2.name);
		}
		if (talentPoints.MageButton3color==1)
		{	
			Debug.Log("You can use " + talentPoints.MageButton3.name);
		}
		if (talentPoints.MageButton4color==1)
		{	
			Debug.Log("You can use " + talentPoints.MageButton4.name);
		}
		if (talentPoints.MageButton5color==1)
		{	
			Debug.Log("You can use " + talentPoints.MageButton5.name);
		}
		if (talentPoints.MageButton6color==1)
		{	
			Debug.Log("You can use " + talentPoints.MageButton6.name);
		}
		if (talentPoints.MageButton7color==1)
		{	
			Debug.Log("You can use " + talentPoints.MageButton7.name);
		}
		if (talentPoints.MageButton8color==1)
		{	
			Debug.Log("You can use " + talentPoints.MageButton8.name);
		}
		if (talentPoints.MageButton9color==1)
		{	
			Debug.Log("You can use " + talentPoints.MageButton9.name);
		}
		if (talentPoints.MageButton10color==1)
		{	
			Debug.Log("You can use " + talentPoints.MageButton10.name);
		}
		if (talentPoints.MageButton11color==1)
		{	
			Debug.Log("You can use " + talentPoints.MageButton11.name);
		}
		if (talentPoints.MageButton12color==1)
		{	
			Debug.Log("You can use " + talentPoints.MageButton12.name);
		}
		if (talentPoints.MageButton13color==1)
		{	
			Debug.Log("You can use " + talentPoints.MageButton13.name);
		}



		if (talentPoints.PriestButton1color == 1) {	
			Debug.Log ("You can use " + talentPoints.PriestButton1.name);
			smite = 1;

		} else
			smite = 0;
		if (talentPoints.PriestButton2color==1)
		{	
			Debug.Log("You can use " + talentPoints.PriestButton2.name);
		}
		if (talentPoints.PriestButton3color==1)
		{	
			Debug.Log("You can use " + talentPoints.PriestButton3.name);
		}
		if (talentPoints.PriestButton4color==1)
		{	
			Debug.Log("You can use " + talentPoints.PriestButton4.name);
		}
		if (talentPoints.PriestButton5color==1)
		{	
			Debug.Log("You can use " + talentPoints.PriestButton5.name);
		}
		if (talentPoints.PriestButton6color==1)
		{	
			Debug.Log("You can use " + talentPoints.PriestButton6.name);
		}
		if (talentPoints.PriestButton7color==1)
		{	
			Debug.Log("You can use " + talentPoints.PriestButton7.name);
		}
		if (talentPoints.PriestButton8color==1)
		{	
			Debug.Log("You can use " + talentPoints.PriestButton8.name);
		}
		if (talentPoints.PriestButton9color==1)
		{	
			Debug.Log("You can use " + talentPoints.PriestButton9.name);
		}
		if (talentPoints.PriestButton10color==1)
		{	
			Debug.Log("You can use " + talentPoints.PriestButton10.name);
		}
		if (talentPoints.PriestButton11color==1)
		{	
			Debug.Log("You can use " + talentPoints.PriestButton11.name);
		}
		if (talentPoints.PriestButton12color==1)
		{	
			Debug.Log("You can use " + talentPoints.PriestButton12.name);
		}
		if (talentPoints.PriestButton13color==1)
		{	
			Debug.Log("You can use " + talentPoints.PriestButton13.name);
		}



		if (talentPoints.BarbarianButton1color == 1) {	
			Debug.Log ("You can use " + talentPoints.BarbarianButton1.name);

			whirlwind = 1;

		} else
			whirlwind = 0;
		if (talentPoints.BarbarianButton2color==1)
		{	
			Debug.Log("You can use " + talentPoints.BarbarianButton2.name);
		}
		if (talentPoints.BarbarianButton3color==1)
		{	
			Debug.Log("You can use " + talentPoints.BarbarianButton3.name);
		}
		if (talentPoints.BarbarianButton4color==1)
		{	
			Debug.Log("You can use " + talentPoints.BarbarianButton4.name);
		}
		if (talentPoints.BarbarianButton5color==1)
		{	
			Debug.Log("You can use " + talentPoints.BarbarianButton5.name);
		}
		if (talentPoints.BarbarianButton6color==1)
		{	
			Debug.Log("You can use " + talentPoints.BarbarianButton6.name);
		}
		if (talentPoints.BarbarianButton7color==1)
		{	
			Debug.Log("You can use " + talentPoints.BarbarianButton7.name);
		}
		if (talentPoints.BarbarianButton8color==1)
		{	
			Debug.Log("You can use " + talentPoints.BarbarianButton8.name);
		}
		if (talentPoints.BarbarianButton9color==1)
		{	
			Debug.Log("You can use " + talentPoints.BarbarianButton9.name);
		}
		if (talentPoints.BarbarianButton10color==1)
		{	
			Debug.Log("You can use " + talentPoints.BarbarianButton10.name);
		}
		if (talentPoints.BarbarianButton11color==1)
		{	
			Debug.Log("You can use " + talentPoints.BarbarianButton11.name);
		}
		if (talentPoints.BarbarianButton12color==1)
		{	
			Debug.Log("You can use " + talentPoints.BarbarianButton12.name);
		}
		if (talentPoints.BarbarianButton13color==1)
		{	
			Debug.Log("You can use " + talentPoints.BarbarianButton13.name);
		}


		if (talentPoints.GuardianButton1color == 1) {	
			Debug.Log ("You can use " + talentPoints.GuardianButton1.name);
			shield_slam = 1;
		} else
			shield_slam = 0;
		if (talentPoints.GuardianButton2color==1)
		{	
			Debug.Log("You can use " + talentPoints.GuardianButton2.name);
		}
		if (talentPoints.GuardianButton3color==1)
		{	
			Debug.Log("You can use " + talentPoints.GuardianButton3.name);
		}
		if (talentPoints.GuardianButton4color==1)
		{	
			Debug.Log("You can use " + talentPoints.GuardianButton4.name);
		}
		if (talentPoints.GuardianButton5color==1)
		{	
			Debug.Log("You can use " + talentPoints.GuardianButton5.name);
		}
		if (talentPoints.GuardianButton6color==1)
		{	
			Debug.Log("You can use " + talentPoints.GuardianButton6.name);
		}
		if (talentPoints.GuardianButton7color==1)
		{	
			Debug.Log("You can use " + talentPoints.GuardianButton7.name);
		}
		if (talentPoints.GuardianButton8color==1)
		{	
			Debug.Log("You can use " + talentPoints.GuardianButton8.name);
		}
		if (talentPoints.GuardianButton9color==1)
		{	
			Debug.Log("You can use " + talentPoints.GuardianButton9.name);
		}
		if (talentPoints.GuardianButton10color==1)
		{	
			Debug.Log("You can use " + talentPoints.GuardianButton10.name);
		}
		if (talentPoints.GuardianButton11color==1)
		{	
			Debug.Log("You can use " + talentPoints.GuardianButton11.name);
		}
		if (talentPoints.GuardianButton12color==1)
		{	
			Debug.Log("You can use " + talentPoints.GuardianButton12.name);
		}
		if (talentPoints.GuardianButton13color==1)
		{	
			Debug.Log("You can use " + talentPoints.GuardianButton13.name);
		}




	}


	 
}
