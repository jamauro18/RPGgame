﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAI : MonoBehaviour {

	GameObject Player;
	public GameObject Target;
	public float AggroDistance = 20f;
	public float speed=4f;
	public float EnemyDamage=5f;


	void OnCollisionEnter (Collision col)
	{
		if(col.gameObject.layer == LayerMask.NameToLayer("Player"))
		{
			GameObject Target = col.gameObject;
			Target.GetComponentInChildren<PlayerHealthBar> ().TakeDamage (EnemyDamage);

		}
		
	}


	void Start()
	{
		
	}


	void Update()
	{
		MoveToTarget ();
		
	}


	void MoveToTarget ()
	{
		GameObject Player = GameObject.Find ("Player");


		transform.LookAt (Player.transform.position);
		transform.Rotate (new Vector3 (0, -90, 0), Space.Self);


		if (Vector3.Distance(Player.transform.position,this.transform.position) < AggroDistance) 
		{
			
			this.transform.Translate (speed*Time.deltaTime,0,0);

			Debug.Log ("I'M GONNA KILL YOU!!!!");
		}
		
		
	}


}