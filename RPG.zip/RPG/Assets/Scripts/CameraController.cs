﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour {

	//Ticket ID :10091446
	/*public float lookSmooth=0.09f;
	public Vector3 offsetFromTarget = new Vector3 (0, 6, -8);
	public float xRotation;
	public float yRotation;
	public float xTilt = 10;
	Vector3 destination = Vector3.zero;
	ControlCharacter charController;*/
	float rotateVel = 0;
	public Transform target;
	CursorLockMode wantedMode;
	Vector2 mousePosition;



	private Vector3 offset;

	[System.Serializable]
	public class PositionSettings
	{
		public Vector3 targetPosOffset= new Vector3(0,5f,0);
		public float lookSmooth = 100f;
		public float distanceFromTarget=-15;
		public float zoomSmooth = 100;
		public float maxZoom = 0;
		public float minZoom = -15;
	}

	[System.Serializable]
	public class OrbitSettings
	{
		public float xRotation = -25;
		public float yRotation = -180;
		public float maxXRotation=180;
		public float minXRotation = 0;
		public float vOrbitSmooth = 150;
		public float hOrbitSmooth = 150;
	}
	[System.Serializable]
	public class InputSettings
	{
		public string ORBIT_HORIZONTAL_SNAP = "OrbitHorizontalSnap";
		//public string ORBIT_HORIZONTAL = "Mouse X";
		public string ORBIT_VERTICAL = "Mouse Y";
		public string ZOOM = "Mouse ScrollWheel";
	}

	public PositionSettings position = new PositionSettings ();
	public OrbitSettings orbit = new OrbitSettings();
	public InputSettings input = new InputSettings ();

	Vector3 targetPos = Vector3.zero;
	Vector3 destination = Vector3.zero;
	ControlCharacter charController;
	float vOrbitInput,hOrbitInput,zoomInput,hOrbitSnapInput;


	void Start()
	{
		
		SetCameraTarget (target);

	}

	void SetCameraTarget(Transform t)
	{
		target = t;
		if (target != null) 
		{
			if (target.GetComponent<ControlCharacter> ()) 
			{
				charController = target.GetComponent<ControlCharacter>();
			}else
			{Debug.LogError("The camera's target needs your character controller");
				
			}
			
		} else
			Debug.LogError ("You dont have a target");
	}
	void FixedUpdate()
	{
		
		OrbitTarget ();
			

	}
	void Update()
	{
		
		ZoomInOnTarget ();
		SetCursorState();

	}


	void LateUpdate()
	{


		//moving
		MoveToTarget();
		//rotating
		LookAtTarget();


	}
		

	void MoveToTarget()
	{

		targetPos = target.position + position.targetPosOffset;
		destination = Quaternion.Euler (orbit.xRotation, orbit.yRotation+target.eulerAngles.y, 0) * -Vector3.forward * position.distanceFromTarget;
		destination += target.position;
		transform.position = destination;

	}

	void LookAtTarget()
	{

		Quaternion targetRotation = Quaternion.LookRotation (targetPos - transform.position);
		transform.rotation = Quaternion.Lerp (transform.rotation, targetRotation, position.lookSmooth * Time.deltaTime);
	}



	void SetCursorState()
	{
		
		if(Input.GetMouseButton(1))
		{
			wantedMode = CursorLockMode.Locked;
		}
		Cursor.lockState = wantedMode;
		// Hide cursor when locking
		Cursor.visible = (CursorLockMode.Locked != wantedMode);

	}



	void OrbitTarget()
	{
		if (Input.GetMouseButton(1)) 
		{
			
			vOrbitInput = Input.GetAxisRaw (input.ORBIT_VERTICAL);
			//hOrbitInput = Input.GetAxis (input.ORBIT_HORIZONTAL);
		}else
		{
			Cursor.lockState = wantedMode = CursorLockMode.None;
			vOrbitInput = 0;
		}
			


		hOrbitSnapInput = Input.GetAxisRaw (input.ORBIT_HORIZONTAL_SNAP);
		if (hOrbitSnapInput > 0) 
		{
			orbit.yRotation = -180;
		}

			orbit.xRotation += -vOrbitInput * orbit.vOrbitSmooth * Time.deltaTime;
			orbit.yRotation += -hOrbitInput * orbit.hOrbitSmooth * Time.deltaTime;



		if (orbit.xRotation > orbit.maxXRotation) 
		{
			orbit.xRotation = orbit.maxXRotation;
		}
		if (orbit.xRotation < orbit.minXRotation) 
		{
			orbit.xRotation = orbit.minXRotation;
		}
	}

	void ZoomInOnTarget()
	{
		zoomInput = Input.GetAxisRaw (input.ZOOM);
		position.distanceFromTarget += zoomInput * position.zoomSmooth;

		if(position.distanceFromTarget > position.maxZoom)
		{
			position.distanceFromTarget = position.maxZoom;
		}

		if(position.distanceFromTarget < position.minZoom)
		{
			position.distanceFromTarget = position.minZoom;
		}
	}
}
