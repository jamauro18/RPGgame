﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HealthBar : MonoBehaviour {


	//public Image playerHealthBar;
	public Image targetHealthBar;
	//public float playerMaxHealth = 100f;
	public float targetMaxHealth = 100f;
	//public static float playerHealth;
	public float targetHealth =100;
	public float Exp = 100;




	// Use this for initialization
	void Start () {
		
		targetHealthBar =  GetComponent<Image> ();

		targetHealth = targetMaxHealth;
	}

	// Update is called once per frame
	void Update () {
		targetHealthBar.fillAmount = targetHealth / targetMaxHealth;
		targetHealthBar.transform.rotation = Camera.main.transform.rotation;

	}

	public void TakeDamage(float Damage)
	{
		
		if (targetHealth > 0) 
		{
			targetHealth -= Damage;
			if (targetHealth<=0)
			{
				Destroy (this.transform.parent.parent.gameObject);
				GameObject.FindWithTag ("Player").GetComponent<Character> ().Experience (Exp);


			}
		}

	}
}
